import {Component} from "@angular/core"
import {HttpClient} from "@angular/common/http"

var productsapi = "https://ashuapi.herokuapp.com/api/allproducts"
@Component({
  selector:"app-root",
  templateUrl:"./app.component.html"
})
export class AppComponent{

  constructor(private http :  HttpClient){
   this.http.get(productsapi).subscribe((response)=>{
     this.products = response["data"]; 
   },(error)=>{
     console.log("error from products api" , error)
   })
  }
  products = []
}


