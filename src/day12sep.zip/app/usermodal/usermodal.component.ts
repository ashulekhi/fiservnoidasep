import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usermodal',
  templateUrl: './usermodal.component.html',
  styleUrls: ['./usermodal.component.css']
})
export class UsermodalComponent implements OnInit {

  showSignup = true
  showLogin = false

  showSignupModal(){
    this.showSignup = true
    this.showLogin = false
  }
  showLoginModal(){
    this.showLogin = true
    this.showSignup = false
    
  }
  constructor() { }

  ngOnInit() {
  }

}
