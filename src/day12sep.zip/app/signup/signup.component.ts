import {Component} from "@angular/core"

@Component({
    selector:'app-signup',
    templateUrl:'./signup.component.html'
})
export class SignupComponent{

    showError = false;

    user = {
        name:"Dummy USer",
        email:"test@test.com",
        password:"test"
    }

    register(){
        this.user.name = "Name Changed"
        if(this.user.email=="test@test.com"&&this.user.password=="test"){

        }
        else{
            
            this.showError = true;
           
        }
        console.log("user has entered" , this.user)
    }





}